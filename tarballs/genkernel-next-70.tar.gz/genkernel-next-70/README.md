# [![build status](https://gitlab.com/mudler/genkernel-next/badges/master/build.svg)](https://gitlab.com/mudler/genkernel-next/commits/master)  Genkernel-next
An improved and modern remake of Gentoo genkernel (in: udev, plymouth; out: cross compiler support)
